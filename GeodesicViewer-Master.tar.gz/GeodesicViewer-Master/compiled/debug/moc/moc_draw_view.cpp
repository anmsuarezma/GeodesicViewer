/****************************************************************************
** Meta object code from reading C++ file 'draw_view.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../view/draw_view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'draw_view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_DrawView_t {
    QByteArrayData data[64];
    char stringdata[941];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_DrawView_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_DrawView_t qt_meta_stringdata_DrawView = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 12),
QT_MOC_LITERAL(2, 22, 0),
QT_MOC_LITERAL(3, 23, 12),
QT_MOC_LITERAL(4, 36, 16),
QT_MOC_LITERAL(5, 53, 3),
QT_MOC_LITERAL(6, 57, 7),
QT_MOC_LITERAL(7, 65, 11),
QT_MOC_LITERAL(8, 77, 1),
QT_MOC_LITERAL(9, 79, 1),
QT_MOC_LITERAL(10, 81, 1),
QT_MOC_LITERAL(11, 83, 6),
QT_MOC_LITERAL(12, 90, 6),
QT_MOC_LITERAL(13, 97, 3),
QT_MOC_LITERAL(14, 101, 8),
QT_MOC_LITERAL(15, 110, 2),
QT_MOC_LITERAL(16, 113, 2),
QT_MOC_LITERAL(17, 116, 2),
QT_MOC_LITERAL(18, 119, 6),
QT_MOC_LITERAL(19, 126, 3),
QT_MOC_LITERAL(20, 130, 7),
QT_MOC_LITERAL(21, 138, 13),
QT_MOC_LITERAL(22, 152, 16),
QT_MOC_LITERAL(23, 169, 14),
QT_MOC_LITERAL(24, 184, 15),
QT_MOC_LITERAL(25, 200, 17),
QT_MOC_LITERAL(26, 218, 18),
QT_MOC_LITERAL(27, 237, 18),
QT_MOC_LITERAL(28, 256, 9),
QT_MOC_LITERAL(29, 266, 17),
QT_MOC_LITERAL(30, 284, 17),
QT_MOC_LITERAL(31, 302, 19),
QT_MOC_LITERAL(32, 322, 19),
QT_MOC_LITERAL(33, 342, 19),
QT_MOC_LITERAL(34, 362, 18),
QT_MOC_LITERAL(35, 381, 19),
QT_MOC_LITERAL(36, 401, 17),
QT_MOC_LITERAL(37, 419, 17),
QT_MOC_LITERAL(38, 437, 17),
QT_MOC_LITERAL(39, 455, 21),
QT_MOC_LITERAL(40, 477, 13),
QT_MOC_LITERAL(41, 491, 18),
QT_MOC_LITERAL(42, 510, 15),
QT_MOC_LITERAL(43, 526, 15),
QT_MOC_LITERAL(44, 542, 16),
QT_MOC_LITERAL(45, 559, 17),
QT_MOC_LITERAL(46, 577, 18),
QT_MOC_LITERAL(47, 596, 17),
QT_MOC_LITERAL(48, 614, 21),
QT_MOC_LITERAL(49, 636, 22),
QT_MOC_LITERAL(50, 659, 14),
QT_MOC_LITERAL(51, 674, 20),
QT_MOC_LITERAL(52, 695, 18),
QT_MOC_LITERAL(53, 714, 18),
QT_MOC_LITERAL(54, 733, 11),
QT_MOC_LITERAL(55, 745, 18),
QT_MOC_LITERAL(56, 764, 22),
QT_MOC_LITERAL(57, 787, 23),
QT_MOC_LITERAL(58, 811, 16),
QT_MOC_LITERAL(59, 828, 24),
QT_MOC_LITERAL(60, 853, 28),
QT_MOC_LITERAL(61, 882, 20),
QT_MOC_LITERAL(62, 903, 17),
QT_MOC_LITERAL(63, 921, 18)
    },
    "DrawView\0calcGeodesic\0\0colorChanged\0"
    "lastPointChanged\0num\0setType\0setPosition\0"
    "x\0y\0z\0setPOI\0setFoV\0fov\0setScale\0sx\0"
    "sy\0sz\0setFog\0fog\0density\0showNumPoints\0"
    "slot_setDrawType\0slot_setAbsOrd\0"
    "slot_setScaling\0slot_resetScaling\0"
    "slot_centerScaling\0slot_adjustScaling\0"
    "slot_zoom\0slot_set2dFGcolor\0"
    "slot_set2dBGcolor\0slot_set2dGridColor\0"
    "slot_set2dLineWidth\0slot_setMouseHandle\0"
    "slot_setProjection\0slot_setFieldOfView\0"
    "slot_adjustCamera\0slot_setCameraPos\0"
    "slot_setCameraPoi\0slot_setCameraPredefs\0"
    "slot_resetPoi\0slot_setDrawType3d\0"
    "slot_setFGcolor\0slot_setBGcolor\0"
    "slot_setEmbColor\0slot_setLineWidth\0"
    "slot_setSmoothLine\0slot_set3dScaling\0"
    "slot_set3dScalingStep\0slot_set3dScalingReset\0"
    "slot_setStereo\0slot_setStereoParams\0"
    "slot_setStereoStep\0slot_setStereoType\0"
    "slot_setFog\0slot_setFogDensity\0"
    "slot_setFogDensityStep\0slot_anim_rot_startstop\0"
    "slot_anim_rotate\0slot_setAnimRotateParams\0"
    "slot_setAnimRotateParamsStep\0"
    "slot_embParamChanged\0slot_adjustAPname\0"
    "slot_showNumPoints\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DrawView[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      53,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  279,    2, 0x05,
       3,    0,  280,    2, 0x05,
       4,    1,  281,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
       6,    1,  284,    2, 0x0a,
       7,    3,  287,    2, 0x0a,
      11,    3,  294,    2, 0x0a,
      12,    1,  301,    2, 0x0a,
      14,    3,  304,    2, 0x0a,
      18,    2,  311,    2, 0x0a,
      18,    1,  316,    2, 0x2a,
      21,    1,  319,    2, 0x0a,
      22,    0,  322,    2, 0x09,
      23,    0,  323,    2, 0x09,
      24,    0,  324,    2, 0x09,
      25,    0,  325,    2, 0x09,
      26,    0,  326,    2, 0x09,
      27,    0,  327,    2, 0x09,
      28,    0,  328,    2, 0x09,
      29,    0,  329,    2, 0x09,
      30,    0,  330,    2, 0x09,
      31,    0,  331,    2, 0x09,
      32,    0,  332,    2, 0x09,
      33,    0,  333,    2, 0x09,
      34,    0,  334,    2, 0x09,
      35,    0,  335,    2, 0x09,
      36,    0,  336,    2, 0x09,
      37,    0,  337,    2, 0x09,
      38,    0,  338,    2, 0x09,
      39,    0,  339,    2, 0x09,
      40,    0,  340,    2, 0x09,
      41,    0,  341,    2, 0x09,
      42,    0,  342,    2, 0x09,
      43,    0,  343,    2, 0x09,
      44,    0,  344,    2, 0x09,
      45,    0,  345,    2, 0x09,
      46,    0,  346,    2, 0x09,
      47,    0,  347,    2, 0x09,
      48,    0,  348,    2, 0x09,
      49,    0,  349,    2, 0x09,
      50,    0,  350,    2, 0x09,
      51,    0,  351,    2, 0x09,
      52,    0,  352,    2, 0x09,
      53,    0,  353,    2, 0x09,
      54,    0,  354,    2, 0x09,
      55,    0,  355,    2, 0x09,
      56,    0,  356,    2, 0x09,
      57,    0,  357,    2, 0x09,
      58,    0,  358,    2, 0x09,
      59,    0,  359,    2, 0x09,
      60,    0,  360,    2, 0x09,
      61,    0,  361,    2, 0x09,
      62,    0,  362,    2, 0x09,
      63,    1,  363,    2, 0x09,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,    8,    9,   10,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,    8,    9,   10,
    QMetaType::Void, QMetaType::Double,   13,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,   15,   16,   17,
    QMetaType::Void, QMetaType::Int, QMetaType::Double,   19,   20,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,

       0        // eod
};

void DrawView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        DrawView *_t = static_cast<DrawView *>(_o);
        switch (_id) {
        case 0: _t->calcGeodesic(); break;
        case 1: _t->colorChanged(); break;
        case 2: _t->lastPointChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->setType((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->setPosition((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 5: _t->setPOI((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 6: _t->setFoV((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 7: _t->setScale((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 8: _t->setFog((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 9: _t->setFog((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->showNumPoints((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->slot_setDrawType(); break;
        case 12: _t->slot_setAbsOrd(); break;
        case 13: _t->slot_setScaling(); break;
        case 14: _t->slot_resetScaling(); break;
        case 15: _t->slot_centerScaling(); break;
        case 16: _t->slot_adjustScaling(); break;
        case 17: _t->slot_zoom(); break;
        case 18: _t->slot_set2dFGcolor(); break;
        case 19: _t->slot_set2dBGcolor(); break;
        case 20: _t->slot_set2dGridColor(); break;
        case 21: _t->slot_set2dLineWidth(); break;
        case 22: _t->slot_setMouseHandle(); break;
        case 23: _t->slot_setProjection(); break;
        case 24: _t->slot_setFieldOfView(); break;
        case 25: _t->slot_adjustCamera(); break;
        case 26: _t->slot_setCameraPos(); break;
        case 27: _t->slot_setCameraPoi(); break;
        case 28: _t->slot_setCameraPredefs(); break;
        case 29: _t->slot_resetPoi(); break;
        case 30: _t->slot_setDrawType3d(); break;
        case 31: _t->slot_setFGcolor(); break;
        case 32: _t->slot_setBGcolor(); break;
        case 33: _t->slot_setEmbColor(); break;
        case 34: _t->slot_setLineWidth(); break;
        case 35: _t->slot_setSmoothLine(); break;
        case 36: _t->slot_set3dScaling(); break;
        case 37: _t->slot_set3dScalingStep(); break;
        case 38: _t->slot_set3dScalingReset(); break;
        case 39: _t->slot_setStereo(); break;
        case 40: _t->slot_setStereoParams(); break;
        case 41: _t->slot_setStereoStep(); break;
        case 42: _t->slot_setStereoType(); break;
        case 43: _t->slot_setFog(); break;
        case 44: _t->slot_setFogDensity(); break;
        case 45: _t->slot_setFogDensityStep(); break;
        case 46: _t->slot_anim_rot_startstop(); break;
        case 47: _t->slot_anim_rotate(); break;
        case 48: _t->slot_setAnimRotateParams(); break;
        case 49: _t->slot_setAnimRotateParamsStep(); break;
        case 50: _t->slot_embParamChanged(); break;
        case 51: _t->slot_adjustAPname(); break;
        case 52: _t->slot_showNumPoints((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (DrawView::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DrawView::calcGeodesic)) {
                *result = 0;
            }
        }
        {
            typedef void (DrawView::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DrawView::colorChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (DrawView::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DrawView::lastPointChanged)) {
                *result = 2;
            }
        }
    }
}

const QMetaObject DrawView::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_DrawView.data,
      qt_meta_data_DrawView,  qt_static_metacall, 0, 0}
};


const QMetaObject *DrawView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DrawView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DrawView.stringdata))
        return static_cast<void*>(const_cast< DrawView*>(this));
    return QWidget::qt_metacast(_clname);
}

int DrawView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 53)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 53;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 53)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 53;
    }
    return _id;
}

// SIGNAL 0
void DrawView::calcGeodesic()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void DrawView::colorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void DrawView::lastPointChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
