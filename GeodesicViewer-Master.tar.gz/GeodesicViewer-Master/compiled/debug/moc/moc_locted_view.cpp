/****************************************************************************
** Meta object code from reading C++ file 'locted_view.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../view/locted_view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'locted_view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_LoctedView_t {
    QByteArrayData data[25];
    char stringdata[331];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_LoctedView_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_LoctedView_t qt_meta_stringdata_LoctedView = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 12),
QT_MOC_LITERAL(2, 24, 0),
QT_MOC_LITERAL(3, 25, 16),
QT_MOC_LITERAL(4, 42, 15),
QT_MOC_LITERAL(5, 58, 17),
QT_MOC_LITERAL(6, 76, 17),
QT_MOC_LITERAL(7, 94, 18),
QT_MOC_LITERAL(8, 113, 18),
QT_MOC_LITERAL(9, 132, 21),
QT_MOC_LITERAL(10, 154, 19),
QT_MOC_LITERAL(11, 174, 21),
QT_MOC_LITERAL(12, 196, 20),
QT_MOC_LITERAL(13, 217, 19),
QT_MOC_LITERAL(14, 237, 23),
QT_MOC_LITERAL(15, 261, 15),
QT_MOC_LITERAL(16, 277, 11),
QT_MOC_LITERAL(17, 289, 2),
QT_MOC_LITERAL(18, 292, 2),
QT_MOC_LITERAL(19, 295, 2),
QT_MOC_LITERAL(20, 298, 2),
QT_MOC_LITERAL(21, 301, 3),
QT_MOC_LITERAL(22, 305, 3),
QT_MOC_LITERAL(23, 309, 15),
QT_MOC_LITERAL(24, 325, 4)
    },
    "LoctedView\0calcGeodesic\0\0slot_setPosition\0"
    "slot_setPosStep\0slot_decrPosition\0"
    "slot_incrPosition\0slot_resetPosition\0"
    "slot_setLoctedType\0slot_resetLocalTetrad\0"
    "slot_setLocalTetrad\0slot_orthoLocalTetrad\0"
    "slot_setPredefTetrad\0slot_setBoostParams\0"
    "slot_setBoostParamSteps\0slot_resetBoost\0"
    "setPosition\0x0\0x1\0x2\0x3\0num\0val\0"
    "setPredefTetrad\0name\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LoctedView[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
       3,    0,  105,    2, 0x0a,
       4,    0,  106,    2, 0x0a,
       5,    0,  107,    2, 0x0a,
       6,    0,  108,    2, 0x0a,
       7,    0,  109,    2, 0x0a,
       8,    0,  110,    2, 0x0a,
       9,    0,  111,    2, 0x0a,
      10,    0,  112,    2, 0x0a,
      11,    0,  113,    2, 0x0a,
      12,    1,  114,    2, 0x0a,
      13,    0,  117,    2, 0x0a,
      14,    0,  118,    2, 0x0a,
      15,    0,  119,    2, 0x0a,
      16,    4,  120,    2, 0x0a,
      16,    2,  129,    2, 0x0a,
      23,    1,  134,    2, 0x0a,
      23,    1,  137,    2, 0x0a,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,   17,   18,   19,   20,
    QMetaType::Void, QMetaType::Int, QMetaType::Double,   21,   22,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::QString,   24,

       0        // eod
};

void LoctedView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        LoctedView *_t = static_cast<LoctedView *>(_o);
        switch (_id) {
        case 0: _t->calcGeodesic(); break;
        case 1: _t->slot_setPosition(); break;
        case 2: _t->slot_setPosStep(); break;
        case 3: _t->slot_decrPosition(); break;
        case 4: _t->slot_incrPosition(); break;
        case 5: _t->slot_resetPosition(); break;
        case 6: _t->slot_setLoctedType(); break;
        case 7: _t->slot_resetLocalTetrad(); break;
        case 8: _t->slot_setLocalTetrad(); break;
        case 9: _t->slot_orthoLocalTetrad(); break;
        case 10: _t->slot_setPredefTetrad((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->slot_setBoostParams(); break;
        case 12: _t->slot_setBoostParamSteps(); break;
        case 13: _t->slot_resetBoost(); break;
        case 14: _t->setPosition((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 15: _t->setPosition((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 16: _t->setPredefTetrad((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->setPredefTetrad((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (LoctedView::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&LoctedView::calcGeodesic)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject LoctedView::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_LoctedView.data,
      qt_meta_data_LoctedView,  qt_static_metacall, 0, 0}
};


const QMetaObject *LoctedView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LoctedView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_LoctedView.stringdata))
        return static_cast<void*>(const_cast< LoctedView*>(this));
    return QWidget::qt_metacast(_clname);
}

int LoctedView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void LoctedView::calcGeodesic()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
