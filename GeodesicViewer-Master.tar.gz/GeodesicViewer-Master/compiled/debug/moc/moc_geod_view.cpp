/****************************************************************************
** Meta object code from reading C++ file 'geod_view.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../view/geod_view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'geod_view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_GeodView_t {
    QByteArrayData data[29];
    char stringdata[403];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_GeodView_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_GeodView_t qt_meta_stringdata_GeodView = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 12),
QT_MOC_LITERAL(2, 22, 0),
QT_MOC_LITERAL(3, 23, 14),
QT_MOC_LITERAL(4, 38, 19),
QT_MOC_LITERAL(5, 58, 3),
QT_MOC_LITERAL(6, 62, 17),
QT_MOC_LITERAL(7, 80, 15),
QT_MOC_LITERAL(8, 96, 19),
QT_MOC_LITERAL(9, 116, 17),
QT_MOC_LITERAL(10, 134, 18),
QT_MOC_LITERAL(11, 153, 15),
QT_MOC_LITERAL(12, 169, 4),
QT_MOC_LITERAL(13, 174, 4),
QT_MOC_LITERAL(14, 179, 16),
QT_MOC_LITERAL(15, 196, 3),
QT_MOC_LITERAL(16, 200, 11),
QT_MOC_LITERAL(17, 212, 3),
QT_MOC_LITERAL(18, 216, 21),
QT_MOC_LITERAL(19, 238, 16),
QT_MOC_LITERAL(20, 255, 17),
QT_MOC_LITERAL(21, 273, 16),
QT_MOC_LITERAL(22, 290, 20),
QT_MOC_LITERAL(23, 311, 19),
QT_MOC_LITERAL(24, 331, 12),
QT_MOC_LITERAL(25, 344, 12),
QT_MOC_LITERAL(26, 357, 12),
QT_MOC_LITERAL(27, 370, 12),
QT_MOC_LITERAL(28, 383, 18)
    },
    "GeodView\0calcGeodesic\0\0changeGeodType\0"
    "slot_showLastJacobi\0num\0slot_setLegColors\0"
    "slot_setLegFreq\0slot_setSachsSystem\0"
    "slot_setSachsLegs\0slot_setSachsScale\0"
    "setGeodesicType\0type\0name\0setTimeDirection\0"
    "dir\0setVelocity\0val\0slot_setTimeDirection\0"
    "slot_setGeodType\0slot_setDirection\0"
    "slot_setVelocity\0slot_setVelocityStep\0"
    "slot_setOrientation\0slot_incrKsi\0"
    "slot_decrKsi\0slot_incrChi\0slot_decrChi\0"
    "slot_setShowJacobi\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GeodView[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x05,
       3,    0,  130,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
       4,    1,  131,    2, 0x0a,
       6,    0,  134,    2, 0x0a,
       7,    0,  135,    2, 0x0a,
       8,    1,  136,    2, 0x0a,
       9,    1,  139,    2, 0x0a,
      10,    0,  142,    2, 0x0a,
      11,    1,  143,    2, 0x0a,
      11,    1,  146,    2, 0x0a,
      14,    1,  149,    2, 0x0a,
      16,    1,  152,    2, 0x0a,
      18,    0,  155,    2, 0x09,
      19,    0,  156,    2, 0x09,
      20,    0,  157,    2, 0x09,
      21,    0,  158,    2, 0x09,
      22,    0,  159,    2, 0x09,
      23,    0,  160,    2, 0x09,
      24,    0,  161,    2, 0x09,
      25,    0,  162,    2, 0x09,
      26,    0,  163,    2, 0x09,
      27,    0,  164,    2, 0x09,
      28,    0,  165,    2, 0x09,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Double,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GeodView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GeodView *_t = static_cast<GeodView *>(_o);
        switch (_id) {
        case 0: _t->calcGeodesic(); break;
        case 1: _t->changeGeodType(); break;
        case 2: _t->slot_showLastJacobi((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->slot_setLegColors(); break;
        case 4: _t->slot_setLegFreq(); break;
        case 5: _t->slot_setSachsSystem((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->slot_setSachsLegs((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->slot_setSachsScale(); break;
        case 8: _t->setGeodesicType((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->setGeodesicType((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->setTimeDirection((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->setVelocity((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 12: _t->slot_setTimeDirection(); break;
        case 13: _t->slot_setGeodType(); break;
        case 14: _t->slot_setDirection(); break;
        case 15: _t->slot_setVelocity(); break;
        case 16: _t->slot_setVelocityStep(); break;
        case 17: _t->slot_setOrientation(); break;
        case 18: _t->slot_incrKsi(); break;
        case 19: _t->slot_decrKsi(); break;
        case 20: _t->slot_incrChi(); break;
        case 21: _t->slot_decrChi(); break;
        case 22: _t->slot_setShowJacobi(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (GeodView::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&GeodView::calcGeodesic)) {
                *result = 0;
            }
        }
        {
            typedef void (GeodView::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&GeodView::changeGeodType)) {
                *result = 1;
            }
        }
    }
}

const QMetaObject GeodView::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_GeodView.data,
      qt_meta_data_GeodView,  qt_static_metacall, 0, 0}
};


const QMetaObject *GeodView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GeodView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GeodView.stringdata))
        return static_cast<void*>(const_cast< GeodView*>(this));
    return QWidget::qt_metacast(_clname);
}

int GeodView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void GeodView::calcGeodesic()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void GeodView::changeGeodType()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}
QT_END_MOC_NAMESPACE
