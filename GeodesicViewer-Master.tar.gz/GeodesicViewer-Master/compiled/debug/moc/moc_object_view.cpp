/****************************************************************************
** Meta object code from reading C++ file 'object_view.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../view/object_view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'object_view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ObjectView_t {
    QByteArrayData data[12];
    char stringdata[129];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_ObjectView_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_ObjectView_t qt_meta_stringdata_ObjectView = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 14),
QT_MOC_LITERAL(2, 26, 0),
QT_MOC_LITERAL(3, 27, 15),
QT_MOC_LITERAL(4, 43, 5),
QT_MOC_LITERAL(5, 49, 10),
QT_MOC_LITERAL(6, 60, 10),
QT_MOC_LITERAL(7, 71, 10),
QT_MOC_LITERAL(8, 82, 15),
QT_MOC_LITERAL(9, 98, 9),
QT_MOC_LITERAL(10, 108, 10),
QT_MOC_LITERAL(11, 119, 8)
    },
    "ObjectView\0objectsChanged\0\0slot_showSyntax\0"
    "index\0slot_apply\0slot_close\0slot_clear\0"
    "slot_add_object\0addObject\0objectText\0"
    "clearAll\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ObjectView[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   54,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
       3,    1,   55,    2, 0x0a,
       5,    0,   58,    2, 0x0a,
       6,    0,   59,    2, 0x0a,
       7,    0,   60,    2, 0x0a,
       8,    0,   61,    2, 0x0a,
       9,    1,   62,    2, 0x0a,
      11,    0,   65,    2, 0x0a,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,

       0        // eod
};

void ObjectView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ObjectView *_t = static_cast<ObjectView *>(_o);
        switch (_id) {
        case 0: _t->objectsChanged(); break;
        case 1: _t->slot_showSyntax((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->slot_apply(); break;
        case 3: _t->slot_close(); break;
        case 4: _t->slot_clear(); break;
        case 5: _t->slot_add_object(); break;
        case 6: _t->addObject((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->clearAll(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ObjectView::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ObjectView::objectsChanged)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject ObjectView::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ObjectView.data,
      qt_meta_data_ObjectView,  qt_static_metacall, 0, 0}
};


const QMetaObject *ObjectView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ObjectView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ObjectView.stringdata))
        return static_cast<void*>(const_cast< ObjectView*>(this));
    return QWidget::qt_metacast(_clname);
}

int ObjectView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void ObjectView::objectsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
