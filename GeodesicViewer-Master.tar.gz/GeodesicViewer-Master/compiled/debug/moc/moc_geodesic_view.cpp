/****************************************************************************
** Meta object code from reading C++ file 'geodesic_view.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../view/geodesic_view.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'geodesic_view.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_GeodesicView_t {
    QByteArrayData data[62];
    char stringdata[922];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_GeodesicView_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_GeodesicView_t qt_meta_stringdata_GeodesicView = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 17),
QT_MOC_LITERAL(2, 31, 0),
QT_MOC_LITERAL(3, 32, 17),
QT_MOC_LITERAL(4, 50, 17),
QT_MOC_LITERAL(5, 68, 17),
QT_MOC_LITERAL(6, 86, 18),
QT_MOC_LITERAL(7, 105, 18),
QT_MOC_LITERAL(8, 124, 18),
QT_MOC_LITERAL(9, 143, 13),
QT_MOC_LITERAL(10, 157, 16),
QT_MOC_LITERAL(11, 174, 15),
QT_MOC_LITERAL(12, 190, 9),
QT_MOC_LITERAL(13, 200, 10),
QT_MOC_LITERAL(14, 211, 8),
QT_MOC_LITERAL(15, 220, 10),
QT_MOC_LITERAL(16, 231, 21),
QT_MOC_LITERAL(17, 253, 12),
QT_MOC_LITERAL(18, 266, 17),
QT_MOC_LITERAL(19, 284, 19),
QT_MOC_LITERAL(20, 304, 17),
QT_MOC_LITERAL(21, 322, 17),
QT_MOC_LITERAL(22, 340, 15),
QT_MOC_LITERAL(23, 356, 16),
QT_MOC_LITERAL(24, 373, 16),
QT_MOC_LITERAL(25, 390, 21),
QT_MOC_LITERAL(26, 412, 23),
QT_MOC_LITERAL(27, 436, 18),
QT_MOC_LITERAL(28, 455, 20),
QT_MOC_LITERAL(29, 476, 23),
QT_MOC_LITERAL(30, 500, 24),
QT_MOC_LITERAL(31, 525, 21),
QT_MOC_LITERAL(32, 547, 21),
QT_MOC_LITERAL(33, 569, 14),
QT_MOC_LITERAL(34, 584, 19),
QT_MOC_LITERAL(35, 604, 19),
QT_MOC_LITERAL(36, 624, 15),
QT_MOC_LITERAL(37, 640, 17),
QT_MOC_LITERAL(38, 658, 13),
QT_MOC_LITERAL(39, 672, 17),
QT_MOC_LITERAL(40, 690, 20),
QT_MOC_LITERAL(41, 711, 18),
QT_MOC_LITERAL(42, 730, 5),
QT_MOC_LITERAL(43, 736, 9),
QT_MOC_LITERAL(44, 746, 4),
QT_MOC_LITERAL(45, 751, 14),
QT_MOC_LITERAL(46, 766, 3),
QT_MOC_LITERAL(47, 770, 3),
QT_MOC_LITERAL(48, 774, 9),
QT_MOC_LITERAL(49, 784, 14),
QT_MOC_LITERAL(50, 799, 4),
QT_MOC_LITERAL(51, 804, 3),
QT_MOC_LITERAL(52, 808, 9),
QT_MOC_LITERAL(53, 818, 9),
QT_MOC_LITERAL(54, 828, 3),
QT_MOC_LITERAL(55, 832, 15),
QT_MOC_LITERAL(56, 848, 10),
QT_MOC_LITERAL(57, 859, 12),
QT_MOC_LITERAL(58, 872, 5),
QT_MOC_LITERAL(59, 878, 15),
QT_MOC_LITERAL(60, 894, 12),
QT_MOC_LITERAL(61, 907, 13)
    },
    "GeodesicView\0slot_load_setting\0\0"
    "slot_save_setting\0slot_load_vparams\0"
    "slot_save_vparams\0slot_reset_vparams\0"
    "slot_save_image_2d\0slot_save_image_3d\0"
    "slot_load_all\0slot_prot_dialog\0"
    "slot_write_prot\0slot_quit\0slot_reset\0"
    "slot_doc\0slot_about\0slot_changeDrawActive\0"
    "slot_animate\0slot_load_objects\0"
    "slot_append_objects\0slot_save_objects\0"
    "slot_show_objects\0slot_objChanged\0"
    "slot_show_report\0slot_save_report\0"
    "slot_setCurrentMetric\0slot_metricParamChanged\0"
    "slot_setGeodSolver\0slot_setMaxNumPoints\0"
    "slot_setStepsizeControl\0"
    "slot_setIntegratorParams\0slot_setDrawWithLines\0"
    "slot_setConstraintEps\0slot_setResize\0"
    "slot_setMaxStepSize\0slot_setMinStepSize\0"
    "slot_setSIunits\0slot_setGeomUnits\0"
    "slot_setUnits\0slot_calcGeodesic\0"
    "slot_setOpenGLcolors\0slot_executeScript\0"
    "reset\0setMetric\0name\0setMetricParam\0"
    "num\0val\0setSolver\0setSolverParam\0wait\0"
    "sec\0addObject\0MyObject*\0obj\0clearAllObjects\0"
    "closeEvent\0QCloseEvent*\0event\0"
    "slot_newConnect\0slot_disconn\0slot_readData\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GeodesicView[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      53,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  279,    2, 0x0a,
       3,    0,  280,    2, 0x0a,
       4,    0,  281,    2, 0x0a,
       5,    0,  282,    2, 0x0a,
       6,    0,  283,    2, 0x0a,
       7,    0,  284,    2, 0x0a,
       8,    0,  285,    2, 0x0a,
       9,    0,  286,    2, 0x0a,
      10,    0,  287,    2, 0x0a,
      11,    0,  288,    2, 0x0a,
      12,    0,  289,    2, 0x0a,
      13,    0,  290,    2, 0x0a,
      14,    0,  291,    2, 0x0a,
      15,    0,  292,    2, 0x0a,
      16,    0,  293,    2, 0x0a,
      17,    0,  294,    2, 0x0a,
      18,    0,  295,    2, 0x0a,
      19,    0,  296,    2, 0x0a,
      20,    0,  297,    2, 0x0a,
      21,    0,  298,    2, 0x0a,
      22,    0,  299,    2, 0x0a,
      23,    0,  300,    2, 0x0a,
      24,    0,  301,    2, 0x0a,
      25,    0,  302,    2, 0x0a,
      26,    0,  303,    2, 0x0a,
      27,    0,  304,    2, 0x0a,
      28,    0,  305,    2, 0x0a,
      29,    0,  306,    2, 0x0a,
      30,    0,  307,    2, 0x0a,
      31,    0,  308,    2, 0x0a,
      32,    0,  309,    2, 0x0a,
      33,    0,  310,    2, 0x0a,
      34,    0,  311,    2, 0x0a,
      35,    0,  312,    2, 0x0a,
      36,    0,  313,    2, 0x0a,
      37,    0,  314,    2, 0x0a,
      38,    0,  315,    2, 0x0a,
      39,    0,  316,    2, 0x0a,
      40,    0,  317,    2, 0x0a,
      41,    0,  318,    2, 0x0a,
      42,    0,  319,    2, 0x0a,
      43,    1,  320,    2, 0x0a,
      45,    2,  323,    2, 0x0a,
      45,    2,  328,    2, 0x0a,
      48,    1,  333,    2, 0x0a,
      49,    2,  336,    2, 0x0a,
      50,    1,  341,    2, 0x0a,
      52,    1,  344,    2, 0x0a,
      55,    0,  347,    2, 0x0a,
      56,    1,  348,    2, 0x09,
      59,    0,  351,    2, 0x09,
      60,    0,  352,    2, 0x09,
      61,    0,  353,    2, 0x09,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   44,
    QMetaType::Void, QMetaType::Int, QMetaType::Double,   46,   47,
    QMetaType::Void, QMetaType::QString, QMetaType::Double,   44,   47,
    QMetaType::Void, QMetaType::QString,   44,
    QMetaType::Void, QMetaType::QString, QMetaType::Double,   44,   47,
    QMetaType::Void, QMetaType::Double,   51,
    QMetaType::Void, 0x80000000 | 53,   54,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 57,   58,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GeodesicView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GeodesicView *_t = static_cast<GeodesicView *>(_o);
        switch (_id) {
        case 0: _t->slot_load_setting(); break;
        case 1: _t->slot_save_setting(); break;
        case 2: _t->slot_load_vparams(); break;
        case 3: _t->slot_save_vparams(); break;
        case 4: _t->slot_reset_vparams(); break;
        case 5: _t->slot_save_image_2d(); break;
        case 6: _t->slot_save_image_3d(); break;
        case 7: _t->slot_load_all(); break;
        case 8: _t->slot_prot_dialog(); break;
        case 9: _t->slot_write_prot(); break;
        case 10: _t->slot_quit(); break;
        case 11: _t->slot_reset(); break;
        case 12: _t->slot_doc(); break;
        case 13: _t->slot_about(); break;
        case 14: _t->slot_changeDrawActive(); break;
        case 15: _t->slot_animate(); break;
        case 16: _t->slot_load_objects(); break;
        case 17: _t->slot_append_objects(); break;
        case 18: _t->slot_save_objects(); break;
        case 19: _t->slot_show_objects(); break;
        case 20: _t->slot_objChanged(); break;
        case 21: _t->slot_show_report(); break;
        case 22: _t->slot_save_report(); break;
        case 23: _t->slot_setCurrentMetric(); break;
        case 24: _t->slot_metricParamChanged(); break;
        case 25: _t->slot_setGeodSolver(); break;
        case 26: _t->slot_setMaxNumPoints(); break;
        case 27: _t->slot_setStepsizeControl(); break;
        case 28: _t->slot_setIntegratorParams(); break;
        case 29: _t->slot_setDrawWithLines(); break;
        case 30: _t->slot_setConstraintEps(); break;
        case 31: _t->slot_setResize(); break;
        case 32: _t->slot_setMaxStepSize(); break;
        case 33: _t->slot_setMinStepSize(); break;
        case 34: _t->slot_setSIunits(); break;
        case 35: _t->slot_setGeomUnits(); break;
        case 36: _t->slot_setUnits(); break;
        case 37: _t->slot_calcGeodesic(); break;
        case 38: _t->slot_setOpenGLcolors(); break;
        case 39: _t->slot_executeScript(); break;
        case 40: _t->reset(); break;
        case 41: _t->setMetric((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 42: _t->setMetricParam((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 43: _t->setMetricParam((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 44: _t->setSolver((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 45: _t->setSolverParam((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 46: _t->wait((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 47: _t->addObject((*reinterpret_cast< MyObject*(*)>(_a[1]))); break;
        case 48: _t->clearAllObjects(); break;
        case 49: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 50: _t->slot_newConnect(); break;
        case 51: _t->slot_disconn(); break;
        case 52: _t->slot_readData(); break;
        default: ;
        }
    }
}

const QMetaObject GeodesicView::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_GeodesicView.data,
      qt_meta_data_GeodesicView,  qt_static_metacall, 0, 0}
};


const QMetaObject *GeodesicView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GeodesicView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GeodesicView.stringdata))
        return static_cast<void*>(const_cast< GeodesicView*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int GeodesicView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 53)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 53;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 53)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 53;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
